package com.example.videoplayer.Model.ContentPck;

public enum VideoResolution {
    LOW ,MEDIUM ,HIGH;

}
