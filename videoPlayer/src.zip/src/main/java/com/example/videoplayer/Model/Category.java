package com.example.videoplayer.Model;

public enum Category {
    News,Game,Podcast,Music,Live,Society,History
}
