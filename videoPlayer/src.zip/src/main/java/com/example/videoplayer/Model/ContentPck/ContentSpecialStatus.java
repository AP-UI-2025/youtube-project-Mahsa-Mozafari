package com.example.videoplayer.Model.ContentPck;

public enum ContentSpecialStatus {
    SPECIAL,
    NOT_SPECIAL

}
