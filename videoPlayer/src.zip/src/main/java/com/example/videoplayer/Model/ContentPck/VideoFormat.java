package com.example.videoplayer.Model.ContentPck;

public enum VideoFormat {
    MP4,MKV,MOV,WMV
}
