package com.example.videoplayer.Panel;

public class AdminPanel {
}
